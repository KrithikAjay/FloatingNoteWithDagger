package com.krithik.floatingnote.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.krithik.floatingnote.MainActivity
import com.krithik.floatingnote.R


const val INTENT_COMMAND = "com.localazy.quicknote.COMMAND"
const val INTENT_COMMAND_EXIT = "EXIT"
const val INTENT_COMMAND_NOTE = "NOTE"
const  val KEY_TEXT_REPLY = "key_text_reply"


private const val NOTIFICATION_CHANNEL_GENERAL = "note_general"
private const val CODE_FOREGROUND_SERVICE = 1
private const val CODE_EXIT_INTENT = 2
private const val CODE_NOTE_INTENT = 3



class FloatingService : Service() {


    override fun onBind(intent: Intent?): IBinder? = null


    /**
     * Remove the foreground notification and stop the service.
     */
    private fun stopService() {
        stopForeground(true)
        stopSelf()
    }


    /**
     * Create and show the foreground notification.
     */
    @RequiresApi(Build.VERSION_CODES.KITKAT_WATCH)
    private fun showNotification() {

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager



//        val exitIntent = Intent(this, FloatingService::class.java).apply {
//            putExtra(INTENT_COMMAND, INTENT_COMMAND_EXIT)
//        }
        val replyIntent = Intent(this,FloatingService::class.java).apply {
            putExtra(INTENT_COMMAND, INTENT_COMMAND_EXIT)
            flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val pendingReplyIntent = PendingIntent.getActivity(this, CODE_EXIT_INTENT,replyIntent,PendingIntent.FLAG_UPDATE_CURRENT)


        val noteIntent = Intent(this, FloatingService::class.java).apply {
            putExtra(INTENT_COMMAND, INTENT_COMMAND_NOTE)
        }

//        val exitPendingIntent = PendingIntent.getService(
//                this, CODE_EXIT_INTENT, exitIntent, 0
//        )

        val notePendingIntent = PendingIntent.getService(
                this, CODE_NOTE_INTENT, noteIntent, 0
        )

        // From Android O, it's necessary to create a notification channel first.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                with(
                        NotificationChannel(
                                NOTIFICATION_CHANNEL_GENERAL,
                                getString(R.string.notification_channel_general),
                                NotificationManager.IMPORTANCE_DEFAULT
                        )
                ) {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    manager.createNotificationChannel(this)
                }
            } catch (ignored: Exception) {
                // Ignore exception.
            }
        }


            val builder   = NotificationCompat.Builder(
                        this,
                        NOTIFICATION_CHANNEL_GENERAL
                )

                    .setLargeIcon(BitmapFactory.decodeResource(applicationContext.resources,R.drawable.ic_baseline_add_24))
                    .setContentTitle(getString(R.string.app_name))
                    .setContentText(getString(R.string.notification_text))
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .setSmallIcon(R.drawable.ic_baseline_note_24)
                    .setContentIntent(pendingReplyIntent)

        val replyRemoteInput = RemoteInput.Builder(KEY_TEXT_REPLY).run {
            setLabel("AddNote")
            build()
        }
        val replyAction = NotificationCompat.Action.Builder(
                0,"Reply",pendingReplyIntent
        ).addRemoteInput(replyRemoteInput).build()

        manager.notify(CODE_FOREGROUND_SERVICE,builder.build())


            startForeground(CODE_FOREGROUND_SERVICE, build())



    }


    @RequiresApi(Build.VERSION_CODES.KITKAT_WATCH)
    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {

        val command = intent.getStringExtra(INTENT_COMMAND)
        Log.i("ServiceCommand", command.toString())
        // Exit the service if we receive the EXIT command.
        // START_NOT_STICKY is important here, we don't want
        // the service to be relaunched.
        if (command == INTENT_COMMAND_EXIT) {
            Toast.makeText(
                    this,
                    "reply Action",
                    Toast.LENGTH_SHORT
            ).show()
        }

        // Be sure to show the notification first for all commands.
        // Don't worry, repeated calls have no effects.
        showNotification()

        // Show the floating window for adding a new note.
        if (command == INTENT_COMMAND_NOTE) {
            Toast.makeText(
                    this,
                    "Floating window to be added",
                    Toast.LENGTH_SHORT
            ).show()
        }

        return START_STICKY
    }

}